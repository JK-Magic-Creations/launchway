// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('shop', () => {
  test('has title', { tag: '@smoke' }, async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle('Demo Shop');
  });

  test('adds an item to the cart', { tag: ['@smoke', '@cart'] }, async ({ page }) => {
    await page.goto('/');
    await page.getByRole('button', { name: 'Add to cart' }).click();
    await expect(page.locator('#count')).toHaveText('Items: 1');
  });

  test('shows wrong count (fails)', { tag: '@cart' }, async ({ page }) => {
    await page.goto('/');
    await page.getByRole('button', { name: 'Add to cart' }).click();
    await expect(page.locator('#count')).toHaveText('Items: 2', { timeout: 1000 });
  });

  test('flaky: passes on retry', async ({ page }, testInfo) => {
    await page.goto('/');
    test.info().annotations.push({ type: 'issue', description: 'FLAKY-123' });
    expect(testInfo.retry, 'first attempt fails').toBeGreaterThan(0);
  });

  test.skip('checkout not built yet', async ({ page }) => {
    await page.goto('/checkout');
  });

  test('attaches a note', async ({ page }, testInfo) => {
    await page.goto('/');
    await testInfo.attach('note.txt', { body: 'hello from the test', contentType: 'text/plain' });
    console.log('stdout line from test');
  });
});
